import time
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.wait import WebDriverWait
from src.Configure.readProperties import cfg
from src.Configure import config


@pytest.fixture
def setup():
    driver = webdriver.Firefox()
    driver.implicitly_wait(10)
    driver.execute_script("window.scrollTo(0,document.body.scrollHeight)")
    driver.get(cfg.getApplicationURl())
    return driver
