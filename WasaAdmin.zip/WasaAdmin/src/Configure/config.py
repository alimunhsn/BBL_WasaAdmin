
BaseUrl = 'https://172.26.8.181:8089/'
UserName = 'ss2906'
Password = 'Abcd@0423'
# pytest --alluredir \Report
# allure serve \Report
