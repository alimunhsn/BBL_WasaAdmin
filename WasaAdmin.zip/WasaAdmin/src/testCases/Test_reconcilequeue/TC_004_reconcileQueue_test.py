import time

from src.Configure.dashboardPage import DashboardPage
from src.Configure.readProperties import cfg
from src.pages.ReconcileQueuePage import ReconcileQueuePage
from src.pages.login_In_Page import LoginInPage
from src.Configure.baseSetup import setup


class Test_Reconcile_Queue:
    user_name = cfg.getUsername(),
    password = cfg.getPassword()
    select_month = "3"
    index = "17"

    def test_001_reconcile_queue_search(self, setup):
        self.driver = setup
        time.sleep(1)
        self.lp = LoginInPage(self.driver)
        self.lp.select_username(self.user_name)
        self.lp.select_password(self.password)
        self.lp.click_login()
        self.rp = DashboardPage(self.driver)
        self.rp.click_reconciliation_queue_module()
        time.sleep(1)

        self.TRQ = ReconcileQueuePage(self.driver)
        self.TRQ.click_from_date()
        self.TRQ.click_select_month(self.select_month)
        time.sleep(1)
        self.TRQ.select_todate_day()
        time.sleep(2)
        self.TRQ.select_current_date_day()
        self.TRQ.click_search_button()
        time.sleep(1)
        self.driver.quit()

    def test_002_reconcile_resut(self, setup):
        self.driver = setup
        time.sleep(1)
        self.lp = LoginInPage(self.driver)
        self.lp.select_username(self.user_name)
        self.lp.select_password(self.password)
        self.lp.click_login()
        self.rp = DashboardPage(self.driver)
        self.rp.click_reconciliation_queue_module()
        time.sleep(1)

        self.TRQ = ReconcileQueuePage(self.driver)
        self.TRQ.click_from_date()
        self.TRQ.click_select_month(self.select_month)
        time.sleep(1)
        self.TRQ.select_todate_day()
        time.sleep(2)
        self.TRQ.select_current_date_day()
        self.TRQ.click_reset_button()
        time.sleep(1)
        self.driver.quit()
