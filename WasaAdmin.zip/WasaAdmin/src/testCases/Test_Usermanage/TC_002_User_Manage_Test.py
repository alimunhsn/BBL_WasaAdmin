import random
import string
import time

from src.Configure.readProperties import cfg
from src.pages.UserManagementPage import UserManagementPage
from src.pages.login_In_Page import LoginInPage
from src.Configure.baseSetup import setup


class Test_User_Manage:
    user_name = cfg.getUsername()
    passwd = cfg.getPassword()
    fullname = "MD Alimun Hasan"
    # usrName = "alimun1193"
    # usrname = random.randint(alimun , 10001)
    role = "ROLE_SUPER_ADMIN"
    usrStatus = "0"
    usrType = "0"
    userPass = "Brac@1234."
    num = random.randint(1001, 10010)
    userPin = "11234"
    department = "BBLSQA"

    letters = string.ascii_lowercase
    usrName = ''.join((random.choice('alimun2234t') for i in range(3)))

    def test_user_page_reset(self, setup):
        self.driver = setup
        time.sleep(1)
        self.lp = LoginInPage(self.driver)
        self.lp.select_username(self.user_name)
        self.lp.select_password(self.passwd)
        self.lp.click_login()
        time.sleep(1)
        self.um = UserManagementPage(self.driver)
        self.um.click_UM_module()
        self.um.click_Add_user_btn()
        self.um.select_FullName(self.fullname)
        self.um.select_add_Username(self.usrName)
        self.um.select_role_name(self.role)
        self.um.select_usr_status(self.usrStatus)
        self.um.select_usr_type(self.usrType)
        self.um.entry_user_password(self.passwd)
        self.um.entry_user_pin(self.num)
        self.um.entry_department(self.department)
        time.sleep(2)
        self.um.click_button_reset()
        time.sleep(1)
        self.driver.close()

    def test_user_page_create(self, setup):
        self.driver = setup
        time.sleep(1)
        self.lp = LoginInPage(self.driver)
        self.lp.select_username(self.user_name)
        self.lp.select_password(self.passwd)
        self.lp.click_login()
        time.sleep(1)
        self.um = UserManagementPage(self.driver)
        self.um.click_UM_module()
        self.um.click_Add_user_btn()
        self.um.select_FullName(self.fullname)
        self.um.select_add_Username(self.usrName)
        self.um.select_role_name(self.role)
        self.um.select_usr_status(self.usrStatus)
        self.um.select_usr_type(self.usrType)
        self.um.entry_user_password(self.passwd)
        self.um.entry_user_pin(self.num)
        self.um.entry_department(self.department)
        time.sleep(2)
        self.um.click_button_adduser()
        time.sleep(1)
        self.driver.close()
