import random

from seleniumpagefactory.Pagefactory import PageFactory

from seleniumpagefactory.Pagefactory import PageFactory


class UserManagementPage(PageFactory):

    def __init__(self, driver):
        super().__init__()
        self.driver = driver

    locators = {
        'User_Mg_module': ('LINK_TEXT', "User Management"),
        'Add_user_btn': ('CSS', "button[type='button'][data-bs-toggle='modal']"),
        'Full_Name': ('Id', "addFullname"),
        'add_Username': ('Id', "addUsername"),
        'select_role': ('Id', "addRole"),
        'select_usrStatus': ('Id', "addIsActive"),
        'select_usrType': ('Id', "addUserType"),
        'entry_pass': ('Id', "addPassword"),
        'entry_pin': ('Id', "addPin"),
        'entry_dept': ('Id', "addDepartment"),
        'click_reset': ('Id', "addUserResetButton"),
        'click_adduser': ('Id', "addUserButton")

    }

    def click_UM_module(self):
        self.User_Mg_module.click()

    def click_Add_user_btn(self):
        self.Add_user_btn.click()

    def select_FullName(self, fullname):
        self.Full_Name.set_text(fullname)

    def select_add_Username(self, uname):
        self.add_Username.set_text(uname)

    def select_role_name(self, role):
        self.select_role.select_element_by_value(role)

    def select_usr_status(self, usrStatus):
        self.select_usrStatus.select_element_by_value(usrStatus)

    def select_usr_type(self, usrtype):
        self.select_usrType.select_element_by_value(usrtype)

    def entry_user_password(self, usrpass):
        self.entry_pass.set_text(usrpass)

    def entry_user_pin(self, num):
        self.entry_pin.set_text(num)

    def entry_department(self, deprt):
        self.entry_dept.set_text(deprt)

    def click_button_reset(self):
        self.click_reset.click()

    def click_button_adduser(self):
        self.click_adduser.click()
