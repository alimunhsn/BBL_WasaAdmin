import random
import time

from selenium.webdriver.common.by import By
from seleniumpagefactory.Pagefactory import PageFactory
from selenium import webdriver
from seleniumpagefactory.Pagefactory import PageFactory


class TransactionReportPage(PageFactory):

    def __init__(self, driver):
        super().__init__()
        self.driver = driver

    locators = {
        'from_Date': ('Id', "fromDate"),
        'select_month': ('xPath', "/html/body/div[4]/div[1]/div/div/select"),
        'select_date': ('xPath', "/html/body/div[4]/div[2]/div/div[2]/div/span[16]"),
        'to_Date': ('Id', "toDatetimepicker"),
        'select_current_day': ('CSS',
                               "body > div:nth-child(8) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) span[class='flatpickr-day today']"),
        'click_search_btn': ('Id', "dateRangeCheck"),
        'click_pdf_btn': ('Id', "btnDownloadPDF"),
        'click_csv_btn': ('Id', "btnDownloadCSV"),
        'entry_pin': ('Id', "addPin"),
        'entry_dept': ('Id', "addDepartment"),
        'click_reset': ('Id', "addUserResetButton")

    }

    def click_from_Date(self):
        self.from_Date.click()

    def click_select_month(self, value):
        self.select_month.select_element_by_value(value)
        time.sleep(1)
        self.select_date.click()

    def select_toDate_day(self):
        self.to_Date.click()
        time.sleep(1)

    def select_CurrentDate_day(self):
        self.select_current_day.click()
        time.sleep(1)

    def click_search_button(self):
        self.click_search_btn.click()

    def click_pdf_button(self):
        self.click_pdf_btn.click()

    def click_csv_button(self):
        self.click_csv_btn.click()

    def select_usr_status(self, usrStatus):
        self.select_usrStatus.select_element_by_value(usrStatus)

    def select_usr_type(self, usrtype):
        self.select_usrType.select_element_by_value(usrtype)

    def entry_user_password(self, usrpass):
        self.entry_pass.set_text(usrpass)

    def entry_user_pin(self, num):
        self.entry_pin.set_text(num)

    def entry_department(self, deprt):
        self.entry_dept.set_text(deprt)

    def click_button_reset(self):
        self.click_reset.click()
