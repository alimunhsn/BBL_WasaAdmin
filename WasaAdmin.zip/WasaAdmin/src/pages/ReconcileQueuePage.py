import random
import time

from selenium.webdriver.common.by import By
from seleniumpagefactory.Pagefactory import PageFactory
from selenium import webdriver
from seleniumpagefactory.Pagefactory import PageFactory


class ReconcileQueuePage(PageFactory):

    def __init__(self, driver):
        super().__init__()
        self.driver = driver

    locators = {
        'from_Date': ('Id', "fromDate"),
        'select_month': ('xPath', "/html/body/div[4]/div[1]/div/div/select"),
        'select_date': ('xPath', "/html/body/div[4]/div[2]/div/div[2]/div/span[16]"),
        'to_Date': ('Id', "toDatetimepicker"),
        'select_current_day': ('CSS',
                               "body > div:nth-child(8) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) span[class='flatpickr-day today']"),
        'click_search_btn': ('Id', "dateRangeCheck"),
        'click_Reset_btn': ('CSS', "div button[class*='resetAndReload']"),
    }

    def click_from_date(self):
        self.from_Date.click()

    def click_select_month(self, value):
        self.select_month.select_element_by_value(value)
        time.sleep(1)
        self.select_date.click()

    def select_todate_day(self):
        self.to_Date.click()
        time.sleep(1)

    def select_current_date_day(self):
        self.select_current_day.click()
        time.sleep(1)

    def click_search_button(self):
        self.click_search_btn.click()

    def click_reset_button(self):
        self.click_Reset_btn.click()

